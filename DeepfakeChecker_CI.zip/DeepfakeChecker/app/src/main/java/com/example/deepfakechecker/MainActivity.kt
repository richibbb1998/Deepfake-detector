package com.example.deepfakechecker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val PICK_VIDEO_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val pickButton = findViewById<Button>(R.id.pickVideoButton)
        pickButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_VIDEO_REQUEST)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == Activity.RESULT_OK) {
            val videoUri = data?.data
            videoUri?.let { uploadVideoToServer(it) }
        }
    }

    private fun uploadVideoToServer(videoUri: Uri) {
        val bytes = contentResolver.openInputStream(videoUri)?.readBytes()
        val client = OkHttpClient()
        val reqBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video","video.mp4",
                RequestBody.create("video/mp4".toMediaTypeOrNull(), bytes!!))
            .build()
        val req = Request.Builder()
            .url("http://10.0.2.2:8000/check")
            .post(reqBody)
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = runOnUiThread {
                Toast.makeText(this@MainActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
            }
            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string()
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Результат: $res", Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}